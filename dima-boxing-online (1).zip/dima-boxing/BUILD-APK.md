# Cara jadi APK (gratis, tanpa install Android Studio)
1. Buat akun github.com, lalu buat repository baru.
2. Upload SEMUA isi folder ini, termasuk folder .github (paling mudah dari laptop).
   Jika folder .github tidak ikut: Add file > Create new file > nama `.github/workflows/apk.yml`, tempel isinya.
3. Buka tab Actions > Build APK > Run workflow. Tunggu sampai centang hijau.
4. Buka hasil run, unduh `dima-boxing-apk` di bagian Artifacts, ekstrak, instal app-debug.apk.

# Mabar
Kedua HP perlu internet. Pemain 1: MABAR ONLINE > BUAT ROOM. Pemain 2: isi kode > GABUNG.
