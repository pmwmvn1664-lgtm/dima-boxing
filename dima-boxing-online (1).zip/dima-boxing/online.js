// ========== MABAR ONLINE 1 vs 1 (WebRTC lewat PeerJS, lockstep; host = P1 kiri, tamu = P2 kanan) ==========
(()=>{
const DT=1/60,DELAY=6,PRE='dimaboxing-a17-',VER=1;
let peer=null,conn=null,N=null,pick={k:0,sk:0},isHost=false;
const o_reset=reset,o_begin=begin,o_openSet=openSet,o_loop=loop;
// ---- UI lobi ----
const css=document.createElement('style');css.textContent=`
#mb{position:fixed;left:50%;top:max(8px,env(safe-area-inset-top));transform:translateX(-50%);z-index:5}
#lb{position:fixed;inset:0;background:#120a22f2;z-index:10;display:none;overflow:auto;color:#fff;font:10px/1.8 "Press Start 2P",monospace;text-align:center;padding:24px 12px;touch-action:auto;box-sizing:border-box}
#lb button,#mb,#lb input,#lb select{font:10px "Press Start 2P",monospace;padding:12px;margin:6px;border:2px solid #ffd23f;border-radius:4px;background:#3a2a68;color:#fff}
#lb input{width:11em;text-align:center;text-transform:uppercase;user-select:text;-webkit-user-select:text}
#code{font-size:26px;color:#ffd23f;letter-spacing:4px;margin:12px;user-select:text}
#net{position:fixed;left:0;right:0;bottom:0;z-index:6;text-align:center;font:8px "Press Start 2P",monospace;color:#ffd23f;pointer-events:none}`;
document.head.appendChild(css);
const el=h=>{const d=document.createElement('div');d.innerHTML=h;const e=d.firstElementChild;document.body.appendChild(e);return e};
const mb=el('<button id="mb">MABAR ONLINE</button>');
const lb=el(`<div id="lb"><h2>MABAR ONLINE</h2>
<div>PETARUNG: <select id="ch">${CH.map((c,i)=>`<option value="${i}">${c.n}</option>`).join('')}</select>
<label><input type="checkbox" id="sk" style="width:auto"> WUJUD SKIN</label></div>
<div><button id="host">BUAT ROOM</button></div><div id="code"></div>
<div><input id="jc" maxlength="5" placeholder="KODE" autocomplete="off"><button id="join">GABUNG</button></div>
<p id="st"></p><button id="close">KEMBALI</button></div>`);
const nl=el('<div id="net"></div>');
const $=id=>document.getElementById(id),say=t=>$('st').textContent=t;
const chosen=()=>({k:+$('ch').value,sk:$('sk').checked?1:0});
function loadLib(){if(window.Peer)return Promise.resolve();
 const add=src=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=src;s.onload=ok;s.onerror=()=>{s.remove();no()};document.head.appendChild(s)});
 return add('peerjs.min.js').catch(()=>add('https://cdn.jsdelivr.net/npm/peerjs@1.5.5/dist/peerjs.min.js'))}
function drop(){const c=conn,p=peer;conn=peer=null;try{c&&c.close()}catch(e){}try{p&&p.destroy()}catch(e){}$('code').textContent=''}
function leave(msg){const was=!!N;if(N){sel=N.old.sel;opp=N.old.opp;CFG.map=N.old.map;GM='versus';DUO=0;N=null;S='modes';reset()}drop();nl.textContent='';
 if(was&&msg){lb.style.display='block';say(msg)}else if(msg)say(msg)}
const send=m=>{if(conn&&conn.open)conn.send(m)};
function wire(c){conn=c;
 c.on('data',onData);c.on('close',()=>{if(conn===c)leave('LAWAN KELUAR / KONEKSI PUTUS')});
 c.on('error',()=>{if(conn===c)leave('KONEKSI BERMASALAH')})}
async function open(host){drop();isHost=host;const code=host?Array.from({length:5},()=>'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.random()*32|0]).join(''):$('jc').value.trim().toUpperCase();
 if(!host&&code.length!==5){say('ISI KODE 5 HURUF');return}
 say('MENYAMBUNG...');try{await loadLib()}catch(e){say('TIDAK ADA INTERNET');return}
 const p=peer=host?new Peer(PRE+code):new Peer();
 p.on('error',e=>{if(peer!==p)return;leave(e.type==='peer-unavailable'?'ROOM TIDAK DITEMUKAN':'GAGAL: '+e.type)});
 p.on('open',()=>{if(host){$('code').textContent=code;say('KIRIM KODE INI KE TEMAN')}
  else{const c=p.connect(PRE+code,{reliable:true});wire(c);c.on('open',()=>send({t:'hello',v:VER,...chosen()}));
   setTimeout(()=>{if(peer===p&&!N)leave('GAGAL TERHUBUNG. COBA JARINGAN LAIN')},15000)}});
 if(host)p.on('connection',c=>{if(conn){c.on('open',()=>c.close());return}pick=chosen();wire(c)})}
// ---- pertandingan ----
let guestPick=null;
function hostStart(){const m={t:'start',a:pick,b:guestPick,seed:Math.random()*1e9|0,id:(N?N.id:0)+1};send(m);start(m)}
function seeded(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function withRng(f,fn){const o=Math.random;Math.random=seeded(N.seed+f*7919);try{fn()}finally{Math.random=o}}
const blank=()=>({m:0,a:0,b:0,c:false});
function start(m){const old=N?N.old:{sel,opp,map:CFG.map};
 N={id:m.id,a:m.a,b:m.b,seed:m.seed,old,f:0,sf:0,acc:0,last:performance.now(),i:[blank(),blank()],q:[{},{}],snap:{},fix:null,wait:0,again:0,quit:0};
 for(let f=0;f<DELAY;f++)N.q[0][f]=N.q[1][f]=[0,0,0,0];
 lb.style.display='none';GM='versus';DUO=1;sel=m.a.k;opp=m.b.k;CFG.map=0;MAPI=0;
 wins=[0,0];round=1;lvl=1;shake=hs=cheer=zm=fl=slowT=0;ts=1;
 ctl.a=ctl.b=0;withRng(0,startRound)}
function onData(d){
 if(d.t==='hello'&&isHost){if(d.v!==VER){send({t:'ver'});return}guestPick={k:d.k%CH.length|0,sk:d.sk?1:0};hostStart()}
 else if(d.t==='ver')leave('VERSI GAME BERBEDA');
 else if(d.t==='start'&&!isHost)start(d);
 else if(d.t==='again'&&isHost&&N&&S==='over')hostStart();
 else if(N&&d.id===N.id){if(d.t==='in')N.q[isHost?1:0][d.f]=d.d;else if(d.t==='sync')N.fix=d}}
// pilih petarung sesuai kedua pemain (tanpa bonus level, supaya adil)
reset=function(){o_reset();if(!N)return;
 [[P1,N.a,0],[E1,N.b,1]].forEach(([f,p,i])=>{f.ch=p.sk?skinCh(CH[p.k]):CH[p.k];f.pal=f.ch.pal;f.inp=N.i[i]});gsWarm(P1);gsWarm(E1)};
const state=()=>[P1,E1].map(f=>[f.x,f.hp,f.st,f.pw]);
function sync(){const x=N.fix;if(!x||!N.snap[x.f])return;const mine=N.snap[x.f];
 [P1,E1].forEach((f,n)=>['x','hp','st','pw'].forEach((k,j)=>{const d=x.s[n][j]-mine[n][j];if(Math.abs(d)>.01)f[k]+=d}));N.fix=null}
function tick(){const me=isHost?0:1,t=N.f+DELAY;
 if(N.sf<=t){const d=[ctl.km||ctl.jm,ctl.a>0?1:0,ctl.b>0?1:0,(ctl.kc||ctl.tc)?1:0];ctl.a=ctl.b=0;N.q[me][t]=d;send({t:'in',id:N.id,f:t,d});N.sf=t+1}
 if(!N.q[0][N.f]||!N.q[1][N.f])return false;
 for(let n=0;n<2;n++){const I=N.i[n],d=N.q[n][N.f];I.m=d[0];if(d[1])I.a=.18;if(d[2])I.b=.18;I.c=!!d[3];I.a-=DT;I.b-=DT;delete N.q[n][N.f]}
 st_t+=DT;if(hs>0)hs-=DT;else{slowT-=DT;ts+=((slowT>0?.3:1)-ts)*Math.min(1,DT*7);withRng(N.f+1,()=>sim(DT*ts))}
 if(N.f%20===0){const s=state();if(isHost)send({t:'sync',id:N.id,f:N.f,s});else{N.snap[N.f]=s;delete N.snap[N.f-600]}}
 if(!isHost)sync();N.f++;return true}
loop=function(now){mb.style.display=!N&&(S==='title'||S==='modes')?'':'none';
 if(!N){o_loop(now);return}
 if(now-last<10){requestAnimationFrame(loop);return}
 HBUD=0;if(cv.width!==W*2){cv.width=W*2;cv.height=H*2;cv.style.imageRendering='pixelated'}g.setTransform(2,0,0,2,0,0);g.imageSmoothingEnabled=false;
 const el_=Math.min(.25,(now-last)/1000);last=now;N.acc=Math.min(.25,N.acc+el_);ctl.va-=el_;ctl.vb-=el_;
 let k=0;while(N.acc>=DT&&k<8){if(!tick())break;N.acc-=DT;k++}
 if(k)N.wait=0;else if(N.acc>=DT)N.wait+=el_;
 draw();
 nl.textContent=N.wait>15?'':N.wait>.5?'MENUNGGU LAWAN...':performance.now()<N.quit?'TEKAN GIR LAGI UNTUK KELUAR':'KAMU: '+(isHost?'P1 (KIRI)':'P2 (KANAN)');
 if(N.wait>15)leave('KONEKSI PUTUS');
 requestAnimationFrame(loop)};
begin=function(){if(!N){o_begin();return}if(S!=='over'||performance.now()<N.again)return;N.again=performance.now()+1500;if(isHost)hostStart();else send({t:'again'})};
// saat online tidak ada jeda: tombol gir = keluar (tekan 2x)
openSet=function(){if(!N){o_openSet();return}if(document.hidden)return;if(performance.now()<N.quit)leave('KAMU KELUAR');else N.quit=performance.now()+2500};
mb.onclick=()=>{$('ch').value=sel;say('');lb.style.display='block'};
$('host').onclick=()=>open(true);$('join').onclick=()=>open(false);
$('close').onclick=()=>{drop();lb.style.display='none'};
// ketikan di lobi tidak diteruskan ke kontrol game
['keydown','keyup'].forEach(t=>lb.addEventListener(t,e=>e.stopPropagation()));
})();
